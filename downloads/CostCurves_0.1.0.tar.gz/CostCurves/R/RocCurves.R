####################################################################
#Funcion CURVA ROC - Algoritmo trivial
#Inputs: predictions, classes , ...
#predictions: list of Scores array values
#classes: list of class boolean array
#uniquec: option to use the same array classes for each predictions
#array in a list.
#positive Y: Set axix
#... : plot options (hold, gridOFF, pointsOFF, legendOFF,
#      main, xlab, ylab, nameClassifiers lwd, lty, col, pch, cex...)
####################################################################
RocCurves=function(predictions, classes, positiveY=FALSE, plotCH=TRUE,uniquec=FALSE, hold=FALSE, plotOFF=FALSE,
                   gridOFF=TRUE, pointsOFF=TRUE, legendOFF=FALSE,
                   main, xlab, ylab, namesClassifiers, lwd, lty, col, pch, cex,
                   xPosLegend,yPosLegend, cexL){
####################################################################
  Np =length(predictions)
  if(!exists("TP_FP.rates", mode="function")) source("TP_FP.rates.R")
  if ((typeof(predictions)!="list")||(typeof(classes)!="list")){
    stop("Predictions type and classes type must be a list")
  }
  if(missing(col)){col=c("cadetblue4", heat.colors(Np-1))}
  if(missing(pch)){pch=sample(c(0,1,2,5,6,c(15:25)),Np, replace=F)}
  if(missing(lwd)){lwd=2}
  if(missing(lty)){lty=rep(1, Np)}
  if(missing(cex)){cex=1.2}
  if (length(lty)==1){lty=rep(lty[1], Np)}
  if (length(pch)==1){pch=rep(pch[1], Np)}
  if (length(col)==1){col=rep(col[1], Np)
  if (Np>1){
  warning(
    "You have more than one curve to plot,
    you should define other colors to visualize curves better")}}
  if(missing(main)){main="ROC Curve (TP vs. FP)"}
  if(missing(xlab)){
    if (positiveY==FALSE){xlab="F1"}else{xlab="F0"}}
  if(missing(ylab)){
    if (positiveY==FALSE){ylab="F0"}else{ylab="F1"}}
  if(missing(xPosLegend)){xPosLegend=0.6}
  if(missing(yPosLegend)){yPosLegend=0.3}
  if(missing(cexL)){cexL=0.75}
  if(plotOFF==FALSE){
    if(hold==FALSE){
      plot.new()
      plot.window(xlim=c(0,1),ylim=c(0,1),xaxs="i", yaxs="i");
      axis(1, at=seq(from = 0, to = 1, by = 0.1));
      axis(2,at=seq(from = 0, to = 1, by = 0.1));
      box();
      if(gridOFF==FALSE){
        grid(nx = 10, ny =10,col = "lightgray", lty = "dotted",
             lwd = par("lwd"), equilogs = TRUE)}
      title(main=main,xlab=xlab,ylab=ylab,font.main= 14)}}
  if(missing(namesClassifiers)){
    namesClassifiers=NULL
    for (i in seq(Np)){namesClassifiers=c(namesClassifiers,
                                          paste("C", i, sep=""))}}
  ####################################################################

  result1<-c(NULL)
  result2<-c(NULL)
  nameslegend <-c(NULL)
  namesResult1 <- c(NULL)
  namesResult2 <- c(NULL)

  for (pred in seq(predictions)){
    if (positiveY==FALSE){
    S<-unlist(predictions[pred])}else{
      S<-(1-unlist(predictions[pred]))
    }

      if (uniquec==TRUE) {
        if (positiveY==FALSE){
        c<-unlist(classes)}else{
          c<-(1-unlist(classes))}}

      else{
        if (length(predictions)!=length(classes)){
          stop ("prediction list and classes list may have the same length")}
        else{
          if (positiveY==FALSE){
          c<-unlist(classes[pred])}else{
            c<-(1-(unlist(classes[pred])))}}
      }
  rates=TP_FP.rates(S,c)
  if(plotOFF==FALSE){
  lines(rates, type="l", col=col[pred] ,lty=lty[pred] ,lwd=lwd)
  if(pointsOFF==FALSE){
    points(rates[,1],rates[,2],col=col[pred],pch =pch[pred],cex = cex)}}
  XY<-rates[c(length(which(rates[,1]==0)):length(rates[,1])),]
  AUC=round(auc(XY[,1], XY[,2], dens=1000), 3)

  namesResult1 = c(namesResult1, paste(namesClassifiers[pred], "AUC:", sep=" "))

  ConveXH<-chull(rates);
  if(length(ConveXH)>3){
    ConveXH<-ConveXH[-c(1,(length(ConveXH)))];
    ConveXH<-c(ConveXH,(length(rates)/2))}
  else{ConveXH<-ConveXH[-1];}
  AUCH=round(auc(rates[ConveXH, 1], rates[ConveXH, 2], dens=1000), 3)
  if(plotOFF==FALSE){if(plotCH==TRUE){
    namesResult2 = c(namesResult2, paste(namesClassifiers[pred], "AUCH:", sep=" "))
    lines(rates[ConveXH, ],col=col[pred],lty = 5 ,lwd=lwd)}}

  nameslegend = c(nameslegend, paste(namesClassifiers[pred], "AUC: ",
                                     AUC, " AUCH: ",
                                     AUCH, sep=""))

  result1=c(result1, AUC)
  result2=c(result2, AUCH)}
  ####################################################################
  #Legend
  if(plotOFF==FALSE){
    if(legendOFF == FALSE){
      legend(xPosLegend, yPosLegend, nameslegend, lty = lty, col = col,cex=cexL,
             y.intersp=0.7, x.intersp=0.3, bty="n"); box()
    }}
  names(result1)<-namesResult1
  names(result2)<-namesResult2
  return(list(result1, result2))
  }
